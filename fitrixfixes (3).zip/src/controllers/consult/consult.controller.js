const productModel = require("../../models/product.model");
const controller = require("../.controller");

// ───────────────────────────────────────────────
// مشاور هوش مصنوعی مکمل‌های ورزشی
// از هر API سازگار با OpenAI استفاده می‌کند. در .env تنظیم کنید:
//   AI_API_URL   (پیش‌فرض: OpenRouter)
//   AI_API_KEY   (کلید — برای OpenRouter رایگان از openrouter.ai بگیرید)
//   AI_MODEL     (پیش‌فرض: مدل رایگان)
// ───────────────────────────────────────────────

const AI_API_URL =
  process.env.AI_API_URL || "https://openrouter.ai/api/v1/chat/completions";
const AI_MODEL =
  process.env.AI_MODEL || "meta-llama/llama-3.3-70b-instruct:free";

// محدودیت نرخ ساده در حافظه: هر IP حداکثر ۱۰ پیام در ۵ دقیقه
const RATE_WINDOW_MS = 5 * 60 * 1000;
const RATE_MAX = 10;
const rateMap = new Map();

function rateLimited(ip) {
  const now = Date.now();
  const entry = rateMap.get(ip) || { count: 0, start: now };
  if (now - entry.start > RATE_WINDOW_MS) {
    entry.count = 0;
    entry.start = now;
  }
  entry.count += 1;
  rateMap.set(ip, entry);
  // پاک‌سازی تنبل برای جلوگیری از رشد بی‌رویه
  if (rateMap.size > 5000) rateMap.clear();
  return entry.count > RATE_MAX;
}

// کش ۵ دقیقه‌ای فهرست محصولات برای پرامپت سیستم
let catalogCache = { text: "", at: 0 };

async function getCatalogText() {
  const now = Date.now();
  if (catalogCache.text && now - catalogCache.at < 5 * 60 * 1000)
    return catalogCache.text;

  const products = await productModel
    .find({ isActive: true, quantity: { $gt: 0 } }, "title priceSingle slug")
    .populate("category", "title")
    .sort({ soldCount: -1 })
    .limit(40)
    .lean();

  const text = products
    .map(
      (p) =>
        `- ${p.title} | ${p.category?.title || "-"} | ${(
          p.priceSingle || 0
        ).toLocaleString("fa-IR")} تومان | /product/${p.slug}`,
    )
    .join("\n");

  catalogCache = { text, at: now };
  return text;
}

class consultController extends controller {
  // صفحه‌ی مشاوره
  async page(req, res, next) {
    try {
      const siteUrl = `${req.protocol}://${req.get("host")}`;
      return res.render("shop/consult", {
        pageTitle: "مشاوره رایگان مکمل با هوش مصنوعی",
        metaDescription:
          "مشاوره رایگان و آنلاین مکمل‌های ورزشی با هوش مصنوعی؛ بپرسید چه مکملی برای هدف و شرایط شما مناسب است — پروتئین، کراتین، گینر و بیشتر.",
        canonicalUrl: `${siteUrl}/consult`,
      });
    } catch (err) {
      next(err);
    }
  }

  // API گفتگو
  async ask(req, res, next) {
    try {
      const ip =
        req.ip || req.headers["x-forwarded-for"] || req.socket.remoteAddress;
      if (rateLimited(String(ip))) {
        return res.status(429).json({
          success: false,
          message:
            "تعداد پیام‌های شما زیاد است؛ لطفاً چند دقیقه بعد دوباره تلاش کنید.",
        });
      }

      if (!process.env.AI_API_KEY) {
        return res.status(503).json({
          success: false,
          message:
            "سرویس مشاوره هنوز فعال نشده است. (مدیر سایت باید AI_API_KEY را در تنظیمات قرار دهد)",
        });
      }

      // اعتبارسنجی ورودی: آرایه‌ی پیام‌ها با نقش و متن محدود
      let { messages } = req.body || {};
      if (!Array.isArray(messages)) messages = [];
      messages = messages
        .filter(
          (m) =>
            m &&
            (m.role === "user" || m.role === "assistant") &&
            typeof m.content === "string" &&
            m.content.trim().length > 0,
        )
        .slice(-10)
        .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

      if (!messages.length || messages[messages.length - 1].role !== "user") {
        return res
          .status(400)
          .json({ success: false, message: "پیامی ارسال نشده است." });
      }

      const catalog = await getCatalogText().catch(() => "");

      const system = [
        "تو «مشاور فیت‌ریکس» هستی؛ فقط و فقط مشاور مکمل ورزشی و تغذیه‌ی ورزشی فروشگاه فیت ریکس شاپ.",
        "قوانین سخت (تخطی ممنوع):",
        "1) فقط به سوالات مرتبط با مکمل ورزشی، تغذیه ورزشی، تمرین و محصولات این فروشگاه پاسخ بده. هر سوال دیگری (عمومی، سیاسی، برنامه‌نویسی، ریاضی، ترجمه و...) را فقط با این جمله رد کن: «من فقط مشاور مکمل و تغذیه ورزشی فیت‌ریکس هستم 🙂 سوال‌تان را در همین زمینه بپرسید.»",
        "2) پیشنهاد محصول فقط از «فهرست محصولات» پایین. لینک را دقیقاً با فرمت [نام محصول](/product/slug) از همان فهرست بیاور. هرگز محصول، قیمت یا لینکی از خودت نساز. اگر محصول مناسبی در فهرست نبود، صادقانه بگو فعلاً در فروشگاه موجود نیست و فقط راهنمایی کلی بده.",
        "3) کوتاه و مستقیم جواب بده؛ بدون مقدمه، تعارف و تکرار. حداکثر ۲ محصول پیشنهاد بده.",
        "4) توصیه‌ی پزشکی نده. فقط اگر کاربر از بیماری، دارو، بارداری یا سن زیر ۱۸ گفت، با یک جمله به پزشک ارجاع بده.",
        "قیمت‌ها به تومان است.",
        "",
        "فهرست محصولات (نام | دسته | قیمت | لینک):",
        catalog || "(فهرست در دسترس نیست — هیچ محصولی پیشنهاد نده)",
      ].join("\n");

      const response = await fetch(AI_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.AI_API_KEY}`,
        },
        body: JSON.stringify({
          model: AI_MODEL,
          messages: [{ role: "system", content: system }, ...messages],
          max_tokens: 450,
          temperature: 0.4,
        }),
      });

      if (!response.ok) {
        const errText = await response.text().catch(() => "");
        console.error("AI API error:", response.status, errText.slice(0, 300));
        return res.status(502).json({
          success: false,
          message:
            "ارتباط با سرویس هوش مصنوعی برقرار نشد؛ لطفاً بعداً تلاش کنید.",
        });
      }

      const data = await response.json();
      const reply =
        data?.choices?.[0]?.message?.content?.trim() ||
        "متاسفانه پاسخی دریافت نشد؛ دوباره تلاش کنید.";

      return res.json({ success: true, reply });
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new consultController();
