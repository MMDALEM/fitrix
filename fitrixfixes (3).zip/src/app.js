const express = require("express");
const app = express();
const mongoose = require("mongoose");
const http = require("http");
require("dotenv").config();
const { SERVER_PORT } = process.env;
const { DATABASE_MONGODB_URL } = process.env;
const createError = require("http-errors");
const { AllRouters } = require("./routers/router");
const cookieParser = require("cookie-parser");
const expressLayouts = require("express-ejs-layouts");
const path = require("path");
const Helpers = require("./Helpers");
const session = require("express-session");
const { updateExchangeRate } = require("./services/exchangeRate.service");
const { startExchangeRateCron } = require("./jobs/exchangeRate.job");
const GlobalData = require("./middlewares/globalData");
const flash = require("./middlewares/flash.middleware");

module.exports = class Application {
  constructor() {
    this.configServer();
    this.createServer();
    this.createMongodb();
    this.createRoutes();
    this.errorHandler();
  }

  configServer() {
    // پشت reverse proxy (nginx) با SSL اجرا می‌شویم؛ با این تنظیم
    // req.protocol مقدار واقعی (https) را از هدر X-Forwarded-Proto می‌خواند.
    // در غیر این صورت callbackUrl درگاه با http ساخته می‌شود و مرورگر
    // هنگام بازگشت از درگاه هشدار «اتصال ناامن» می‌دهد.
    app.set("trust proxy", true);
    // هدرهای امنیتی (CSP خاموش تا اسکریپت‌های inline قالب نشکنند)
    const helmet = require("helmet");
    app.use(
      helmet({
        contentSecurityPolicy: false,
        crossOriginEmbedderPolicy: false,
        crossOriginResourcePolicy: { policy: "cross-origin" },
      }),
    );
    app.use(express.json({ limit: "100mb" }));
    app.use(express.urlencoded({ limit: "100mb", extended: true }));
    app.use(cookieParser());
    app.use(
      session({
        secret: process.env.SESSION_SECRET,
        resave: false,
        saveUninitialized: true,
        cookie: { maxAge: 24 * 60 * 60 * 1000 },
      }),
    );
    app.use(flash);
    app.use((req, res, next) => {
      res.locals.success_msg = req.flash("success_msg");
      res.locals.error_msg = req.flash("error_msg");
      next();
    });
    app.use(express.static(path.join(__dirname, "..", "public")));
    app.set("view engine", "ejs");
    app.set("views", path.resolve("./resource/views"));
    app.use(expressLayouts);
    app.set("layout extractScripts", true);
    app.set("layout extractStyles", true);
    app.set("layout", "home/master");
    app.use((req, res, next) => {
      app.locals = new Helpers(req, res).getObjects();
      next();
    });
  }

  createServer() {
    const server = http.createServer(app);
    server.listen(SERVER_PORT, () =>
      console.log(`server run to PORT : ${SERVER_PORT}`),
    );
  }

  createMongodb() {
    mongoose.connect(DATABASE_MONGODB_URL, { autoIndex: true });
    mongoose.set("strictPopulate", true);
    mongoose.set("strictQuery", true);
    mongoose.connection.on("connected", async () => {
      console.log(`connect to mongodb `);
      // حذف ایندکس قدیمیِ unique روی baskets.user
      // (هر کاربر حالا چند سبد دارد: یک active + چند paid)
      try {
        const coll = mongoose.connection.db.collection("baskets");
        const indexes = await coll.indexes();
        if (indexes.some((i) => i.name === "user_1")) {
          await coll.dropIndex("user_1");
          console.log("dropped legacy baskets.user_1 unique index");
        }
      } catch (e) {
        console.log("basket index cleanup skipped:", e.message);
      }
    });
    mongoose.connection.on("desconnected", () =>
      console.log(`desconnect to mongodb `),
    );
  }

  createRoutes() {
    app.use(GlobalData.init());
    app.use(AllRouters);
  }

  exchangeRate() {
    updateExchangeRate();
    startExchangeRateCron();
  }

  errorHandler() {
    app.use((req, res, next) => {
      next(createError.NotFound("آدرس مورد نظر پیدا نشد"));
    });
    app.use((error, req, res, next) => {
      if (error.code === "LIMIT_FILE_SIZE")
        return res
          .status(400)
          .json({ message: "حجم فایل نباید بیشتر از 3 مگابایت باشد." });
      const serverError = createError.InternalServerError(error);
      const message = error.message || serverError.message;
      const status = error.status || serverError.status;

      // برای درخواست‌های مرورگر، صفحه‌ی ۴۰۴ واقعی (کد وضعیت درست برای سئو)
      if (status === 404 && req.accepts("html")) {
        return res.status(404).render("home/404", {
          pageTitle: "صفحه پیدا نشد",
          noindex: true,
        });
      }

      return res.status(status).json({ message: message });
    });
  }
};
